export let coffeeData = {
  selects: {
    drinkType: "Choose your drink",
    roastType: "Choose the roast",
    specialType: "Available coffee options",
  },
};
