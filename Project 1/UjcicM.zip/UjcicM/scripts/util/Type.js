export const Type = {
  ICED: "iced",
  HOT: "hot",
  COLDBREW: "coldBrew",
};

Object.freeze(Type);
